Name: Junior Samaroo
Student ID# 0663108
CIS3110 Assignment 1

deepthroat.c:
	Sends a message to thewashingtonpost.c
	
thewashingtonpost.c:
	Receives message sent from deepthroat.c
	
A1_docs.txt:
	Brief outline in coding of thewashingtonpost and deepthroat.
	
makefile:
	Makefile used to compile thewashingtonpost.c and deepthroat.c
	
	
	
COMPILATION:
	type "make" within working directory to run the makefile.
	
EXECUTION:
	After compilation user must first run "deepthraot.c" in a terminal 
	followed by "thewashingtonpost.c" in another terminal.
